Projeto individual numero um do curso de programação full stack da Resilia.
Basta extrair a pasta e executar no browser para abrir todo o escopo to html + css